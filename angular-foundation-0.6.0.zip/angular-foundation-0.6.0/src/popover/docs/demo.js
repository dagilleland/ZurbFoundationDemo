angular.module('foundationDemoApp').controller('PopoverDemoCtrl', function ($scope) {
  $scope.dynamicPopover = "Hello, World!";
  $scope.dynamicPopoverTitle = "Title";
});
