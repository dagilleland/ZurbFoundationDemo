angular.module('foundationDemoApp').controller('OffCanvasDemoCtrl', function ($scope) {

});
